<!DOCTYPE html>
<html>
<head>
	<title>Beranda</title>
	<link rel="stylesheet" type="text/css" href="design.css">
</head>
<body>
<?php 
	session_start();
	if($_SESSION['level']==""){
		header("location:index.php?pesan=gagal");
	}
?>
	<h1>Halaman Pegawai</h1>
	<p class="text">Halo <b><?php echo $_SESSION['username']; ?></b> 
Anda telah login sebagai <b><?php echo $_SESSION['level']; ?></b>.</p>
	<center><a href="logout.php">LOGOUT</a></center>
	<br/>
</body>
</html>
